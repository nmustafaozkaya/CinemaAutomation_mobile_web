<?php

use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\PosterUpdateController;
use App\Http\Controllers\UpdateFutureMoviePosters;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;

Route::get('register', function () {
    return view('register');
})->name('register');

Route::get('/', function () {
    return view('dashboard');
})->name('dashboard');

Route::get('/movies', function () {
    return view('movies');
})->name('movies');

Route::get('/tickets', function () {
    return view('tickets');
})->name('tickets');

// ✅ Admin sayfasını koruyalım
Route::get('/admin', function () {
    return view('admin');
})->middleware('admin')->name('admin');

Route::get('/login', function () {
    return view('login');
})->name('login');

Route::get('/modern', function () {
    return view('modern');
})->name('modern');

Route::get('/ticket', function () {
    return view('ticket');
})->name('ticket');

// Basit test
Route::get('/test-user', function () {
    if (Auth::check()) {
        $user = Auth::user();
        return "Giriş yapılmış: " . $user->name . " - Role ID: " . $user->role_id;
    } else {
        return "Giriş yapılmamış!";
    }
});

// Gerçek login sistemi
Route::post('/login', function(Request $request) {
    $credentials = $request->only('email', 'password');
    
    if (Auth::attempt($credentials)) {
        // ✅ Ana sayfaya yönlendir
        return response()->json(['success' => true]);
    }
    
    return response()->json(['success' => false], 401);
});

// ✅ Çıkış sistemi
Route::get('/logout', function() {
    Auth::logout();
    return redirect('/login');
});

Route::get('/my-tickets', function() {
    return view('my-tickets');
})->middleware('auth');

// Test için admin sayfası
Route::get('/admin-test', function () {
    $user = Auth::user();
    return "Merhaba " . $user->name . "! Role ID: " . $user->role_id . " - Role: " . ($user->role_id == 1 ? 'Super Admin' : 'Admin');
})->middleware('admin');

// ✅ Yetki kontrolü olmayan sayfalar için customer testi
Route::get('/customer-test', function () {
    return "Bu sayfayı herkes görebilir! Merhaba " . (Auth::check() ? Auth::user()->name : 'Misafir');
});

// Customer bilet alma
Route::get('/buy-tickets', function () {
    return view('tickets');  // Aynı sayfayı kullan
})->middleware('auth');

Route::get('/test-data', function() {
    return response()->json([
        'movies_count' => \App\Models\Movie::count(),
        'halls_count' => \App\Models\Hall::count() ?? 'Hall model yok',
        'cinemas_count' => \App\Models\Cinema::count()
    ]);
});