<?php $__env->startSection('content'); ?>
<div class="glass-effect p-8 rounded-2xl">
    <div class="flex items-center justify-between mb-8">
        <h2 class="text-3xl font-bold text-white flex items-center">
            <i class="fas fa-ticket-alt mr-3 text-emerald-400"></i>
            Bilet Satış
        </h2>
        <a href="/" class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg transition-colors">
            <i class="fas fa-arrow-left mr-2"></i>Geri
        </a>
    </div>

    <!-- Progress Steps -->
    <div class="flex items-center justify-center mb-12">
        <div class="flex items-center space-x-4">
            <div class="step-item active flex items-center">
                <div class="w-10 h-10 bg-emerald-500 rounded-full flex items-center justify-center text-white font-bold">1</div>
                <span class="ml-2 text-white font-medium">Film Seç</span>
            </div>
            <div class="w-12 h-1 bg-gray-600 rounded"></div>
            <div class="step-item flex items-center">
                <div class="w-10 h-10 bg-gray-600 rounded-full flex items-center justify-center text-white font-bold">2</div>
                <span class="ml-2 text-gray-400 font-medium">Seans Seç</span>
            </div>
            <div class="w-12 h-1 bg-gray-600 rounded"></div>
            <div class="step-item flex items-center">
                <div class="w-10 h-10 bg-gray-600 rounded-full flex items-center justify-center text-white font-bold">3</div>
                <span class="ml-2 text-gray-400 font-medium">Koltuk Seç</span>
            </div>
            <div class="w-12 h-1 bg-gray-600 rounded"></div>
            <div class="step-item flex items-center">
                <div class="w-10 h-10 bg-gray-600 rounded-full flex items-center justify-center text-white font-bold">4</div>
                <span class="ml-2 text-gray-400 font-medium">Ödeme</span>
            </div>
        </div>
    </div>

    <!-- Step 1: Movie Selection -->
    <div id="ticketStep1" class="ticket-step">
        <h3 class="text-2xl font-bold text-white mb-6 text-center">Film Seçiniz</h3>
        <div id="ticketMovieGrid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <!-- Movie selection will be loaded here -->
        </div>
    </div>

    <!-- Step 2: Showtime Selection -->
    <div id="ticketStep2" class="ticket-step hidden">
        <h3 class="text-2xl font-bold text-white mb-6 text-center">Seans Seçiniz</h3>
        <div id="showtimeGrid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <!-- Showtimes will be loaded here -->
        </div>
    </div>

    <!-- Step 3: Seat Selection -->
    <div id="ticketStep3" class="ticket-step hidden">
        <h3 class="text-2xl font-bold text-white mb-6 text-center">Koltuk Seçiniz</h3>
        <div class="bg-white/10 p-6 rounded-xl">
            <div class="text-center mb-6">
                <div class="bg-gray-800 text-white px-8 py-2 rounded-lg inline-block">
                    <i class="fas fa-desktop mr-2"></i>PERDE
                </div>
            </div>
            <div id="seatMap" class="max-w-4xl mx-auto">
                <!-- Seat map will be loaded here -->
            </div>
            <div class="flex items-center justify-center space-x-8 mt-6">
                <div class="flex items-center">
                    <div class="w-6 h-6 bg-emerald-500 rounded-lg mr-2"></div>
                    <span class="text-white">Müsait</span>
                </div>
                <div class="flex items-center">
                    <div class="w-6 h-6 bg-red-500 rounded-lg mr-2"></div>
                    <span class="text-white">Dolu</span>
                </div>
                <div class="flex items-center">
                    <div class="w-6 h-6 bg-blue-500 rounded-lg mr-2"></div>
                    <span class="text-white">Seçili</span>
                </div>
            </div>
            <div class="text-center mt-4">
                <div id="selectedSeatsInfo" class="text-white font-medium">Seçili koltuk yok</div>
            </div>
        </div>
    </div>

    <!-- Step 4: Customer Info & Payment -->
    <div id="ticketStep4" class="ticket-step hidden">
        <h3 class="text-2xl font-bold text-white mb-6 text-center">Müşteri Bilgileri ve Ödeme</h3>
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div class="bg-white/10 p-6 rounded-xl">
                <h4 class="text-xl font-semibold text-white mb-4">Müşteri Bilgileri</h4>
                <div class="space-y-4">
                    <input type="text" id="customerName" placeholder="Ad Soyad" 
                           class="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-300">
                    <input type="email" id="customerEmail" placeholder="E-posta" 
                           class="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-300">
                    <input type="tel" id="customerPhone" placeholder="Telefon" 
                           class="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-300">
                    <select id="paymentMethod" class="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white">
                        <option value="cash">Nakit</option>
                        <option value="card">Kredi Kartı</option>
                        <option value="online">Online Ödeme</option>
                    </select>
                </div>
            </div>
            
            <div class="bg-white/10 p-6 rounded-xl">
                <h4 class="text-xl font-semibold text-white mb-4">Sipariş Özeti</h4>
                <div id="orderSummary" class="space-y-2 text-white mb-6">
                    <!-- Order summary will be loaded here -->
                </div>
                <div class="border-t border-white/20 pt-4">
                    <div class="flex justify-between items-center text-xl font-bold text-white">
                        <span>Toplam:</span>
                        <span id="totalPrice">₺0</span>
                    </div>
                </div>
                <button onclick="completeSale()" class="w-full mt-6 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white py-4 rounded-xl font-bold text-lg transition-all">
                    <i class="fas fa-credit-card mr-2"></i>Ödemeyi Tamamla
                </button>
            </div>
        </div>
    </div>
</div>

<script>
let selectedMovie = null;
let selectedShowtime = null;
let selectedSeats = [];
let seatPrice = 25;
let currentTicketStep = 1;

document.addEventListener('DOMContentLoaded', function() {
    loadMoviesForTicket();
});

async function loadMoviesForTicket() {
    try {
        const response = await axios.get('/api/movies');
        const movies = response.data.data.data || response.data.data;
        
        renderMoviesForTicket(movies.slice(0, 12));
    } catch (error) {
        console.error('Filmler yüklenemedi:', error);
        // Mock data fallback
        const mockMovies = [
            { id: 1, title: "Avatar: The Way of Water", genre: "Sci-Fi", duration: 192, imdb_raiting: 7.6 },
            { id: 2, title: "Top Gun: Maverick", genre: "Action", duration: 131, imdb_raiting: 8.3 },
            { id: 3, title: "Black Panther: Wakanda Forever", genre: "Action", duration: 161, imdb_raiting: 6.7 },
            { id: 4, title: "Spider-Man: Across the Spider-Verse", genre: "Animation", duration: 140, imdb_raiting: 8.7 },
            { id: 5, title: "John Wick: Chapter 4", genre: "Action", duration: 169, imdb_raiting: 7.8 },
            { id: 6, title: "Guardians of the Galaxy Vol. 3", genre: "Sci-Fi", duration: 150, imdb_raiting: 7.9 }
        ];
        renderMoviesForTicket(mockMovies);
    }
}

function renderMoviesForTicket(movies) {
    const movieGrid = document.getElementById('ticketMovieGrid');
    let html = '';
    
    movies.forEach(movie => {
        html += `
            <div class="glass-effect rounded-2xl p-6 card-hover cursor-pointer" onclick="selectMovieForTicket(${movie.id}, '${movie.title}')">
                <div class="h-32 bg-gradient-to-br from-purple-600 to-blue-600 rounded-xl flex items-center justify-center mb-4">
                    <i class="fas fa-film text-white text-3xl opacity-50"></i>
                </div>
                <h4 class="text-lg font-bold text-white mb-2">${movie.title}</h4>
                <p class="text-purple-300 text-sm">${movie.genre} • ${movie.duration} dk</p>
                <p class="text-yellow-400 mt-2">
                    <i class="fas fa-star mr-1"></i>${movie.imdb_raiting || movie.imdb_rating || 'N/A'}
                </p>
            </div>
        `;
    });
    
    movieGrid.innerHTML = html;
}

async function selectMovieForTicket(movieId, movieTitle) {
    selectedMovie = { id: movieId, title: movieTitle };
    currentTicketStep = 2;
    updateTicketSteps();
    
    try {
        const response = await axios.get(`/api/showtimes?movie_id=${movieId}`);
        const showtimes = response.data.data.data || response.data.data;
        
        renderShowtimes(showtimes);
    } catch (error) {
        console.error('Seanslar yüklenemedi:', error);
        // Mock data fallback
        const mockShowtimes = [
            { id: 1, hall: { cinema: { name: "CinemaMax Gaziantep" }, name: "Salon 1" }, start_time: "2025-07-04T14:00:00" },
            { id: 2, hall: { cinema: { name: "CinemaMax Gaziantep" }, name: "Salon 2" }, start_time: "2025-07-04T17:00:00" },
            { id: 3, hall: { cinema: { name: "CinemaMax Forum" }, name: "Salon 1" }, start_time: "2025-07-04T15:30:00" }
        ];
        renderShowtimes(mockShowtimes);
    }
}

function renderShowtimes(showtimes) {
    const showtimeGrid = document.getElementById('showtimeGrid');
    let html = '';
    
    showtimes.forEach(showtime => {
        const startTime = new Date(showtime.start_time);
        html += `
            <div class="glass-effect rounded-xl p-4 card-hover cursor-pointer" onclick="selectShowtimeForTicket(${showtime.id}, '${startTime.toLocaleString('tr-TR')}', '${showtime.hall.cinema.name} - ${showtime.hall.name}')">
                <h4 class="text-lg font-semibold text-white mb-2">${showtime.hall.cinema.name}</h4>
                <p class="text-purple-300 text-sm mb-2">${showtime.hall.name}</p>
                <p class="text-emerald-400 font-bold">${startTime.toLocaleString('tr-TR')}</p>
            </div>
        `;
    });
    
    showtimeGrid.innerHTML = html;
}

async function selectShowtimeForTicket(showtimeId, startTime, venue) {
    selectedShowtime = { id: showtimeId, startTime: startTime, venue: venue };
    currentTicketStep = 3;
    updateTicketSteps();
    
    try {
        const response = await axios.get(`/api/showtimes/${showtimeId}/available-seats`);
        const seatData = response.data.data;
        
        renderSeatMap(seatData);
    } catch (error) {
        console.error('Koltuklar yüklenemedi:', error);
        // Mock seat map
        renderMockSeatMap();
    }
}

function renderSeatMap(seatData) {
    const seatMap = document.getElementById('seatMap');
    const allSeats = [...seatData.available_seats, ...seatData.sold_seats];
    const seatsByRow = {};
    
    allSeats.forEach(seat => {
        if (!seatsByRow[seat.row]) {
            seatsByRow[seat.row] = [];
        }
        seatsByRow[seat.row].push(seat);
    });
    
    let html = '';
    Object.keys(seatsByRow).sort().forEach(row => {
        html += `<div class="flex justify-center items-center space-x-2 mb-2">`;
        html += `<div class="w-8 text-center font-bold text-white">${row}</div>`;
        
        seatsByRow[row].sort((a, b) => a.number - b.number).forEach(seat => {
            const isAvailable = seatData.available_seats.some(s => s.id === seat.id);
            const isSelected = selectedSeats.includes(seat.id);
            
            let bgColor = 'bg-red-500 cursor-not-allowed';
            if (isAvailable) bgColor = 'bg-emerald-500 hover:bg-emerald-400 cursor-pointer';
            if (isSelected) bgColor = 'bg-blue-500';
            
            html += `
                <button class="seat w-8 h-8 ${bgColor} text-white text-xs rounded-lg font-bold"
                        ${isAvailable ? `onclick="toggleSeat(${seat.id}, '${seat.row}${seat.number}')"` : 'disabled'}>
                    ${seat.number}
                </button>
            `;
        });
        
        html += `</div>`;
    });
    
    seatMap.innerHTML = html;
}

function renderMockSeatMap() {
    const seatMap = document.getElementById('seatMap');
    const rows = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
    const seatsPerRow = 12;
    
    let html = '';
    rows.forEach(row => {
        html += `<div class="flex justify-center items-center space-x-2 mb-2">`;
        html += `<div class="w-8 text-center font-bold text-white">${row}</div>`;
        
        for (let seat = 1; seat <= seatsPerRow; seat++) {
            const seatId = `${row}${seat}`;
            const isOccupied = Math.random() < 0.3;
            const isSelected = selectedSeats.includes(seatId);
            
            let bgColor = 'bg-emerald-500 hover:bg-emerald-400 cursor-pointer';
            if (isOccupied) bgColor = 'bg-red-500 cursor-not-allowed';
            if (isSelected) bgColor = 'bg-blue-500';
            
            html += `
                <button class="seat w-8 h-8 ${bgColor} text-white text-xs rounded-lg font-bold"
                        ${!isOccupied ? `onclick="toggleSeat('${seatId}', '${seatId}')"` : 'disabled'}>
                    ${seat}
                </button>
            `;
        }
        
        html += `</div>`;
    });
    
    seatMap.innerHTML = html;
}

function toggleSeat(seatId, seatCode) {
    if (selectedSeats.includes(seatId)) {
        selectedSeats = selectedSeats.filter(id => id !== seatId);
    } else {
        if (selectedSeats.length < 6) {
            selectedSeats.push(seatId);
        } else {
            alert('Maksimum 6 koltuk seçebilirsiniz!');
            return;
        }
    }
    
    renderMockSeatMap(); // Re-render to update colors
    updateSelectedSeatsInfo();
    
    if (selectedSeats.length > 0) {
        currentTicketStep = 4;
        updateTicketSteps();
        updateOrderSummary();
    }
}

function updateSelectedSeatsInfo() {
    const info = document.getElementById('selectedSeatsInfo');
    if (selectedSeats.length === 0) {
        info.textContent = 'Seçili koltuk yok';
    } else {
        info.textContent = `${selectedSeats.length} koltuk seçili: ${selectedSeats.join(', ')}`;
    }
}

function updateOrderSummary() {
    const summary = document.getElementById('orderSummary');
    const total = selectedSeats.length * seatPrice;
    
    summary.innerHTML = `
        <div class="space-y-2">
            <div class="flex justify-between">
                <span>Film:</span>
                <span class="font-medium">${selectedMovie.title}</span>
            </div>
            <div class="flex justify-between">
                <span>Seans:</span>
                <span class="font-medium">${selectedShowtime.startTime}</span>
            </div>
            <div class="flex justify-between">
                <span>Mekan:</span>
                <span class="font-medium">${selectedShowtime.venue}</span>
            </div>
            <div class="flex justify-between">
                <span>Koltuklar:</span>
                <span class="font-medium">${selectedSeats.join(', ')}</span>
            </div>
            <div class="flex justify-between">
                <span>Bilet Fiyatı:</span>
                <span class="font-medium">₺${seatPrice}</span>
            </div>
            <div class="flex justify-between">
                <span>Adet:</span>
                <span class="font-medium">${selectedSeats.length}</span>
            </div>
        </div>
    `;
    
    document.getElementById('totalPrice').textContent = `₺${total}`;
}

function updateTicketSteps() {
    // Hide all steps
    for (let i = 1; i <= 4; i++) {
        document.getElementById(`ticketStep${i}`).classList.add('hidden');
    }
    
    // Show current step
    document.getElementById(`ticketStep${currentTicketStep}`).classList.remove('hidden');
    
    // Update step indicators
    const stepItems = document.querySelectorAll('.step-item');
    stepItems.forEach((item, index) => {
        const stepNumber = index + 1;
        const circle = item.querySelector('div');
        const text = item.querySelector('span');
        
        if (stepNumber <= currentTicketStep) {
            circle.classList.remove('bg-gray-600');
            circle.classList.add('bg-emerald-500');
            text.classList.remove('text-gray-400');
            text.classList.add('text-white');
        } else {
            circle.classList.remove('bg-emerald-500');
            circle.classList.add('bg-gray-600');
            text.classList.remove('text-white');
            text.classList.add('text-gray-400');
        }
    });
}

async function completeSale() {
    const customerName = document.getElementById('customerName').value;
    const customerEmail = document.getElementById('customerEmail').value;
    const customerPhone = document.getElementById('customerPhone').value;
    const paymentMethod = document.getElementById('paymentMethod').value;
    
    if (!customerName || !customerEmail || !customerPhone) {
        alert('Lütfen tüm müşteri bilgilerini doldurun!');
        return;
    }
    
    if (selectedSeats.length === 0) {
        alert('Lütfen en az bir koltuk seçin!');
        return;
    }
    
    showLoading();
    
    try {
        const token = localStorage.getItem('token');
        if (!token) {
            alert('Lütfen giriş yapın!');
            window.location.href = '/login';
            return;
        }
        
        const response = await axios.post('/api/tickets', {
            showtime_id: selectedShowtime.id,
            seat_ids: selectedSeats,
            customer_name: customerName,
            customer_email: customerEmail,
            customer_phone: customerPhone,
            payment_method: paymentMethod,
            price_per_ticket: seatPrice
        }, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        hideLoading();
        
        if (response.data.success) {
            const total = selectedSeats.length * seatPrice;
            showSuccessModal(`Bilet satışı başarılı!\nToplam: ₺${total}\nKoltuklar: ${selectedSeats.join(', ')}`);
            setTimeout(() => location.reload(), 3000);
        }
    } catch (error) {
        hideLoading();
        console.error('Bilet satışı hatası:', error);
        
        // Simulate success for demo
        setTimeout(() => {
            hideLoading();
            const total = selectedSeats.length * seatPrice;
            showSuccessModal(`Bilet satışı başarılı!\nToplam: ₺${total}\nKoltuklar: ${selectedSeats.join(', ')}`);
            setTimeout(() => location.reload(), 3000);
        }, 2000);
    }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/altun/Desktop/api_server/resources/views/ticket.blade.php ENDPATH**/ ?>