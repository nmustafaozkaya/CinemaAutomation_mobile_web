<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🎬 Modern Sinema Otomasyonu</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
        
        * {
            font-family: 'Inter', sans-serif;
        }
        
        .glass-effect {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .gradient-bg {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        
        .card-hover {
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .card-hover:hover {
            transform: translateY(-8px);
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
        }
        
        .seat {
            transition: all 0.2s ease;
        }
        
        .seat:hover {
            transform: scale(1.1);
        }
        
        .loading {
            animation: pulse 2s infinite;
        }
        
        .fade-in {
            animation: fadeIn 0.6s ease-out;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .floating-animation {
            animation: floating 3s ease-in-out infinite;
        }
        
        @keyframes floating {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-10px); }
        }
        
        .neon-border {
            box-shadow: 0 0 20px rgba(59, 130, 246, 0.5);
        }
        
        .stat-card {
            background: linear-gradient(145deg, #ffffff, #f3f4f6);
            box-shadow: 20px 20px 60px #d1d5db, -20px -20px 60px #ffffff;
        }
    </style>
</head>
<body class="bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 min-h-screen">
    <!-- Navigation -->
    <nav class="glass-effect sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-16">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
                        <i class="fas fa-film text-white text-lg"></i>
                    </div>
                    <h1 class="text-xl font-bold text-white">CinemaMax</h1>
                </div>
                <div class="hidden md:flex space-x-8">
                    <a href="#dashboard" class="nav-link text-white hover:text-purple-300 transition-colors">
                        <i class="fas fa-home mr-2"></i>Ana Sayfa
                    </a>
                    <a href="#movies" class="nav-link text-white hover:text-purple-300 transition-colors">
                        <i class="fas fa-play mr-2"></i>Filmler
                    </a>
                    <a href="#tickets" class="nav-link text-white hover:text-purple-300 transition-colors">
                        <i class="fas fa-ticket-alt mr-2"></i>Bilet Satış
                    </a>
                    <a href="#admin" class="nav-link text-white hover:text-purple-300 transition-colors">
                        <i class="fas fa-cog mr-2"></i>Yönetim
                    </a>
                </div>
                <button class="md:hidden text-white">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        <!-- Dashboard Section -->
        <section id="dashboard-section" class="mb-12">
            <!-- Hero Section -->
            <div class="text-center mb-12">
                <div class="floating-animation inline-block mb-6">
                    <div class="w-20 h-20 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto">
                        <i class="fas fa-film text-white text-3xl"></i>
                    </div>
                </div>
                <h1 class="text-5xl font-bold text-white mb-4 bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                    Modern Sinema Deneyimi
                </h1>
                <p class="text-xl text-gray-300 max-w-2xl mx-auto">
                    En yeni filmler, konforlu koltuklar ve dijital ses sistemi ile unutulmaz bir sinema deneyimi yaşayın
                </p>
            </div>

            <!-- Stats Cards -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
                <div class="stat-card p-6 rounded-2xl text-center card-hover">
                    <div class="w-12 h-12 bg-gradient-to-r from-blue-500 to-blue-600 rounded-lg flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-film text-white text-xl"></i>
                    </div>
                    <div class="text-3xl font-bold text-gray-800 mb-2" id="totalMovies">-</div>
                    <div class="text-gray-600 font-medium">Aktif Filmler</div>
                </div>
                
                <div class="stat-card p-6 rounded-2xl text-center card-hover">
                    <div class="w-12 h-12 bg-gradient-to-r from-emerald-500 to-emerald-600 rounded-lg flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-building text-white text-xl"></i>
                    </div>
                    <div class="text-3xl font-bold text-gray-800 mb-2" id="totalCinemas">-</div>
                    <div class="text-gray-600 font-medium">Sinema Salonları</div>
                </div>
                
                <div class="stat-card p-6 rounded-2xl text-center card-hover">
                    <div class="w-12 h-12 bg-gradient-to-r from-purple-500 to-purple-600 rounded-lg flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-clock text-white text-xl"></i>
                    </div>
                    <div class="text-3xl font-bold text-gray-800 mb-2" id="totalShowtimes">-</div>
                    <div class="text-gray-600 font-medium">Günlük Seanslar</div>
                </div>
                
                <div class="stat-card p-6 rounded-2xl text-center card-hover">
                    <div class="w-12 h-12 bg-gradient-to-r from-pink-500 to-pink-600 rounded-lg flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-ticket-alt text-white text-xl"></i>
                    </div>
                    <div class="text-3xl font-bold text-gray-800 mb-2" id="totalTickets">-</div>
                    <div class="text-gray-600 font-medium">Satılan Biletler</div>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div class="glass-effect p-8 rounded-2xl text-center card-hover">
                    <div class="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                        <i class="fas fa-play text-white text-2xl"></i>
                    </div>
                    <h3 class="text-xl font-bold text-white mb-4">Film Listesi</h3>
                    <p class="text-gray-300 mb-6">Vizyondaki tüm filmleri keşfedin</p>
                    <button onclick="showMovies()" class="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white py-3 px-6 rounded-xl font-semibold hover:from-blue-600 hover:to-purple-700 transition-all duration-300">
                        Filmleri Görüntüle
                    </button>
                </div>

                <div class="glass-effect p-8 rounded-2xl text-center card-hover">
                    <div class="w-16 h-16 bg-gradient-to-r from-emerald-500 to-teal-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                        <i class="fas fa-ticket-alt text-white text-2xl"></i>
                    </div>
                    <h3 class="text-xl font-bold text-white mb-4">Bilet Satış</h3>
                    <p class="text-gray-300 mb-6">Hızlı ve kolay bilet satışı yapın</p>
                    <button onclick="showTicketSale()" class="w-full bg-gradient-to-r from-emerald-500 to-teal-600 text-white py-3 px-6 rounded-xl font-semibold hover:from-emerald-600 hover:to-teal-700 transition-all duration-300">
                        Bilet Sat
                    </button>
                </div>

                <div class="glass-effect p-8 rounded-2xl text-center card-hover">
                    <div class="w-16 h-16 bg-gradient-to-r from-pink-500 to-rose-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                        <i class="fas fa-cog text-white text-2xl"></i>
                    </div>
                    <h3 class="text-xl font-bold text-white mb-4">Yönetim Paneli</h3>
                    <p class="text-gray-300 mb-6">Sistem yönetimi ve raporlar</p>
                    <button onclick="showAdmin()" class="w-full bg-gradient-to-r from-pink-500 to-rose-600 text-white py-3 px-6 rounded-xl font-semibold hover:from-pink-600 hover:to-rose-700 transition-all duration-300">
                        Yönetim Paneli
                    </button>
                </div>
            </div>
        </section>

        <!-- Movies Section -->
        <section id="movies-section" class="hidden fade-in">
            <div class="glass-effect p-8 rounded-2xl mb-8">
                <div class="flex items-center justify-between mb-6">
                    <h2 class="text-3xl font-bold text-white flex items-center">
                        <i class="fas fa-play mr-3 text-purple-400"></i>
                        Film Listesi
                    </h2>
                    <button onclick="showDashboard()" class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg transition-colors">
                        <i class="fas fa-arrow-left mr-2"></i>Geri
                    </button>
                </div>
                
                <div class="flex flex-col md:flex-row gap-4 mb-8">
                    <div class="flex-1">
                        <input type="text" id="movieSearch" placeholder="Film adı ile ara..." 
                               class="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-300 focus:bg-white/20 focus:border-purple-400 transition-all">
                    </div>
                    <button onclick="searchMovies()" class="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white px-8 py-3 rounded-xl font-semibold transition-all">
                        <i class="fas fa-search mr-2"></i>Ara
                    </button>
                </div>
            </div>
            
            <div id="movieGrid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                <!-- Movies will be loaded here -->
            </div>
        </section>

        <!-- Ticket Sale Section -->
        <section id="ticket-sale-section" class="hidden fade-in">
            <div class="glass-effect p-8 rounded-2xl">
                <div class="flex items-center justify-between mb-8">
                    <h2 class="text-3xl font-bold text-white flex items-center">
                        <i class="fas fa-ticket-alt mr-3 text-emerald-400"></i>
                        Bilet Satış
                    </h2>
                    <button onclick="showDashboard()" class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg transition-colors">
                        <i class="fas fa-arrow-left mr-2"></i>Geri
                    </button>
                </div>

                <!-- Progress Steps -->
                <div class="flex items-center justify-center mb-12">
                    <div class="flex items-center space-x-4">
                        <div class="step-item active flex items-center">
                            <div class="w-10 h-10 bg-emerald-500 rounded-full flex items-center justify-center text-white font-bold">1</div>
                            <span class="ml-2 text-white font-medium">Film Seç</span>
                        </div>
                        <div class="w-12 h-1 bg-gray-600 rounded"></div>
                        <div class="step-item flex items-center">
                            <div class="w-10 h-10 bg-gray-600 rounded-full flex items-center justify-center text-white font-bold">2</div>
                            <span class="ml-2 text-gray-400 font-medium">Seans Seç</span>
                        </div>
                        <div class="w-12 h-1 bg-gray-600 rounded"></div>
                        <div class="step-item flex items-center">
                            <div class="w-10 h-10 bg-gray-600 rounded-full flex items-center justify-center text-white font-bold">3</div>
                            <span class="ml-2 text-gray-400 font-medium">Koltuk Seç</span>
                        </div>
                        <div class="w-12 h-1 bg-gray-600 rounded"></div>
                        <div class="step-item flex items-center">
                            <div class="w-10 h-10 bg-gray-600 rounded-full flex items-center justify-center text-white font-bold">4</div>
                            <span class="ml-2 text-gray-400 font-medium">Ödeme</span>
                        </div>
                    </div>
                </div>

                <!-- Ticket Sale Steps -->
                <div id="ticketStep1" class="ticket-step">
                    <h3 class="text-2xl font-bold text-white mb-6 text-center">Film Seçiniz</h3>
                    <div id="ticketMovieGrid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        <!-- Movie selection will be loaded here -->
                    </div>
                </div>

                <div id="ticketStep2" class="ticket-step hidden">
                    <h3 class="text-2xl font-bold text-white mb-6 text-center">Seans Seçiniz</h3>
                    <div id="showtimeGrid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        <!-- Showtimes will be loaded here -->
                    </div>
                </div>

                <div id="ticketStep3" class="ticket-step hidden">
                    <h3 class="text-2xl font-bold text-white mb-6 text-center">Koltuk Seçiniz</h3>
                    <div class="bg-white/10 p-6 rounded-xl">
                        <div class="text-center mb-6">
                            <div class="bg-gray-800 text-white px-8 py-2 rounded-lg inline-block">
                                <i class="fas fa-desktop mr-2"></i>PERDE
                            </div>
                        </div>
                        <div id="seatMap" class="max-w-4xl mx-auto">
                            <!-- Seat map will be loaded here -->
                        </div>
                        <div class="flex items-center justify-center space-x-8 mt-6">
                            <div class="flex items-center">
                                <div class="w-6 h-6 bg-emerald-500 rounded-lg mr-2"></div>
                                <span class="text-white">Müsait</span>
                            </div>
                            <div class="flex items-center">
                                <div class="w-6 h-6 bg-red-500 rounded-lg mr-2"></div>
                                <span class="text-white">Dolu</span>
                            </div>
                            <div class="flex items-center">
                                <div class="w-6 h-6 bg-blue-500 rounded-lg mr-2"></div>
                                <span class="text-white">Seçili</span>
                            </div>
                        </div>
                        <div class="text-center mt-4">
                            <div id="selectedSeatsInfo" class="text-white font-medium">Seçili koltuk yok</div>
                        </div>
                    </div>
                </div>

                <div id="ticketStep4" class="ticket-step hidden">
                    <h3 class="text-2xl font-bold text-white mb-6 text-center">Müşteri Bilgileri ve Ödeme</h3>
                    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                        <div class="bg-white/10 p-6 rounded-xl">
                            <h4 class="text-xl font-semibold text-white mb-4">Müşteri Bilgileri</h4>
                            <div class="space-y-4">
                                <input type="text" id="customerName" placeholder="Ad Soyad" 
                                       class="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-300">
                                <input type="email" id="customerEmail" placeholder="E-posta" 
                                       class="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-300">
                                <input type="tel" id="customerPhone" placeholder="Telefon" 
                                       class="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-300">
                                <select id="paymentMethod" class="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white">
                                    <option value="cash">Nakit</option>
                                    <option value="card">Kredi Kartı</option>
                                    <option value="online">Online Ödeme</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="bg-white/10 p-6 rounded-xl">
                            <h4 class="text-xl font-semibold text-white mb-4">Sipariş Özeti</h4>
                            <div id="orderSummary" class="space-y-2 text-white mb-6">
                                <!-- Order summary will be loaded here -->
                            </div>
                            <div class="border-t border-white/20 pt-4">
                                <div class="flex justify-between items-center text-xl font-bold text-white">
                                    <span>Toplam:</span>
                                    <span id="totalPrice">₺0</span>
                                </div>
                            </div>
                            <button onclick="completeSale()" class="w-full mt-6 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white py-4 rounded-xl font-bold text-lg transition-all">
                                <i class="fas fa-credit-card mr-2"></i>Ödemeyi Tamamla
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Admin Section -->
        <section id="admin-section" class="hidden fade-in">
            <div class="glass-effect p-8 rounded-2xl">
                <div class="flex items-center justify-between mb-8">
                    <h2 class="text-3xl font-bold text-white flex items-center">
                        <i class="fas fa-cog mr-3 text-pink-400"></i>
                        Yönetim Paneli
                    </h2>
                    <button onclick="showDashboard()" class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg transition-colors">
                        <i class="fas fa-arrow-left mr-2"></i>Geri
                    </button>
                </div>

                <!-- Admin Tabs -->
                <div class="flex space-x-4 mb-8 overflow-x-auto">
                    <button onclick="showAdminTab('movies')" class="admin-tab-btn active whitespace-nowrap px-6 py-3 rounded-xl font-semibold transition-all">
                        <i class="fas fa-film mr-2"></i>Film Yönetimi
                    </button>
                    <button onclick="showAdminTab('showtimes')" class="admin-tab-btn whitespace-nowrap px-6 py-3 rounded-xl font-semibold transition-all">
                        <i class="fas fa-clock mr-2"></i>Seans Yönetimi
                    </button>
                    <button onclick="showAdminTab('reports')" class="admin-tab-btn whitespace-nowrap px-6 py-3 rounded-xl font-semibold transition-all">
                        <i class="fas fa-chart-bar mr-2"></i>Raporlar
                    </button>
                </div>

                <!-- Admin Tab Contents -->
                <div id="adminMoviesTab" class="admin-tab-content">
                    <div class="flex items-center justify-between mb-6">
                        <h3 class="text-2xl font-bold text-white">Film Yönetimi</h3>
                        <button onclick="showAddMovieForm()" class="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white px-6 py-3 rounded-xl font-semibold transition-all">
                            <i class="fas fa-plus mr-2"></i>Yeni Film Ekle
                        </button>
                    </div>
                    
                    <div id="addMovieForm" class="hidden bg-white/10 p-6 rounded-xl mb-6">
                        <h4 class="text-xl font-semibold text-white mb-4">Yeni Film Ekle</h4>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                            <input type="text" id="newMovieTitle" placeholder="Film Başlığı" class="px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-300">
                            <input type="number" id="newMovieDuration" placeholder="Süre (dakika)" class="px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-300">
                            <input type="text" id="newMovieGenre" placeholder="Tür" class="px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-300">
                            <input type="number" step="0.1" id="newMovieRating" placeholder="IMDB Puanı" class="px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-300">
                            <input type="date" id="newMovieDate" class="px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white">
                            <select id="newMovieLanguage" class="px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white">
                                <option value="tr">Türkçe</option>
                                <option value="en">İngilizce</option>
                            </select>
                        </div>
                        <textarea id="newMovieDescription" placeholder="Film Açıklaması" rows="3" class="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-300 mb-4"></textarea>
                        <div class="flex space-x-4">
                            <button onclick="addMovie()" class="bg-emerald-500 hover:bg-emerald-600 text-white px-6 py-3 rounded-xl font-semibold transition-all">
                                <i class="fas fa-check mr-2"></i>Ekle
                            </button>
                            <button onclick="hideAddMovieForm()" class="bg-gray-600 hover:bg-gray-700 text-white px-6 py-3 rounded-xl font-semibold transition-all">
                                <i class="fas fa-times mr-2"></i>İptal
                            </button>
                        </div>
                    </div>
                    
                    <div id="adminMovieList" class="space-y-4">
                        <!-- Admin movie list will be loaded here -->
                    </div>
                </div>

                <div id="adminShowtimesTab" class="admin-tab-content hidden">
                    <div class="flex items-center justify-between mb-6">
                        <h3 class="text-2xl font-bold text-white">Seans Yönetimi</h3>
                        <button onclick="showAddShowtimeForm()" class="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white px-6 py-3 rounded-xl font-semibold transition-all">
                            <i class="fas fa-plus mr-2"></i>Yeni Seans Ekle
                        </button>
                    </div>
                    
                    <div id="addShowtimeForm" class="hidden bg-white/10 p-6 rounded-xl mb-6">
                        <h4 class="text-xl font-semibold text-white mb-4">Yeni Seans Ekle</h4>
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                            <select id="newShowtimeMovie" class="px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white">
                                <option value="">Film Seçin</option>
                            </select>
                            <select id="newShowtimeHall" class="px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white">
                                <option value="">Salon Seçin</option>
                            </select>
                            <input type="datetime-local" id="newShowtimeStart" class="px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white">
                        </div>
                        <div class="flex space-x-4">
                            <button onclick="addShowtime()" class="bg-emerald-500 hover:bg-emerald-600 text-white px-6 py-3 rounded-xl font-semibold transition-all">
                                <i class="fas fa-check mr-2"></i>Ekle
                            </button>
                            <button onclick="hideAddShowtimeForm()" class="bg-gray-600 hover:bg-gray-700 text-white px-6 py-3 rounded-xl font-semibold transition-all">
                                <i class="fas fa-times mr-2"></i>İptal
                            </button>
                        </div>
                    </div>
                    
                    <div id="adminShowtimeList" class="space-y-4">
                        <!-- Admin showtime list will be loaded here -->
                    </div>
                </div>

                <div id="adminReportsTab" class="admin-tab-content hidden">
                    <h3 class="text-2xl font-bold text-white mb-6">Satış Raporları</h3>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                        <div class="stat-card p-6 rounded-2xl text-center">
                            <div class="w-12 h-12 bg-gradient-to-r from-emerald-500 to-emerald-600 rounded-lg flex items-center justify-center mx-auto mb-4">
                                <i class="fas fa-calendar-day text-white text-xl"></i>
                            </div>
                            <div class="text-3xl font-bold text-gray-800 mb-2" id="dailySales">₺0</div>
                            <div class="text-gray-600 font-medium">Günlük Satış</div>
                        </div>
                        
                        <div class="stat-card p-6 rounded-2xl text-center">
                            <div class="w-12 h-12 bg-gradient-to-r from-blue-500 to-blue-600 rounded-lg flex items-center justify-center mx-auto mb-4">
                                <i class="fas fa-calendar-alt text-white text-xl"></i>
                            </div>
                            <div class="text-3xl font-bold text-gray-800 mb-2" id="monthlySales">₺0</div>
                            <div class="text-gray-600 font-medium">Aylık Satış</div>
                        </div>
                        
                        <div class="stat-card p-6 rounded-2xl text-center">
                            <div class="w-12 h-12 bg-gradient-to-r from-purple-500 to-purple-600 rounded-lg flex items-center justify-center mx-auto mb-4">
                                <i class="fas fa-star text-white text-xl"></i>
                            </div>
                            <div class="text-3xl font-bold text-gray-800 mb-2" id="totalRevenue">₺0</div>
                            <div class="text-gray-600 font-medium">Toplam Gelir</div>
                        </div>
                    </div>
                    
                    <div class="bg-white/10 p-6 rounded-2xl">
                        <h4 class="text-xl font-semibold text-white mb-4">
                            <i class="fas fa-trophy mr-2 text-yellow-400"></i>En Popüler Filmler
                        </h4>
                        <div id="popularMovies" class="space-y-3">
                            <!-- Popular movies will be loaded here -->
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <!-- Success Modal -->
    <div id="successModal" class="fixed inset-0 bg-black bg-opacity-50 hidden flex items-center justify-center z-50">
        <div class="bg-white rounded-2xl p-8 max-w-md mx-4 text-center">
            <div class="w-16 h-16 bg-emerald-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <i class="fas fa-check text-white text-2xl"></i>
            </div>
            <h3 class="text-2xl font-bold text-gray-800 mb-2">İşlem Başarılı!</h3>
            <p id="successMessage" class="text-gray-600 mb-6">İşleminiz başarıyla tamamlandı.</p>
            <button onclick="closeSuccessModal()" class="bg-emerald-500 hover:bg-emerald-600 text-white px-6 py-3 rounded-xl font-semibold transition-all">
                Tamam
            </button>
        </div>
    </div>

    <!-- Loading Overlay -->
    <div id="loadingOverlay" class="fixed inset-0 bg-black bg-opacity-50 hidden flex items-center justify-center z-50">
        <div class="bg-white rounded-2xl p-8 text-center">
            <div class="loading w-12 h-12 border-4 border-purple-500 border-t-transparent rounded-full mx-auto mb-4"></div>
            <p class="text-gray-600 font-medium">Yükleniyor...</p>
        </div>
    </div>

    <script>
        // Global variables
        let selectedMovie = null;
        let selectedShowtime = null;
        let selectedSeats = [];
        let seatPrice = 30;
        let currentTicketStep = 1;

        // Mock data for demo
        const mockMovies = [
            { id: 1, title: "Avatar: The Way of Water", genre: "Sci-Fi", duration: 192, imdb_rating: 7.6, release_date: "2023-01-01", description: "Jake Sully lives with his newfound family formed on the planet of Pandora." },
            { id: 2, title: "Top Gun: Maverick", genre: "Action", duration: 131, imdb_rating: 8.3, release_date: "2023-02-15", description: "After thirty years, Maverick is still pushing the envelope as a top naval aviator." },
            { id: 3, title: "Black Panther: Wakanda Forever", genre: "Action", duration: 161, imdb_rating: 6.7, release_date: "2023-03-01", description: "The people of Wakanda fight to protect their home from intervening world powers." },
            { id: 4, title: "Spider-Man: Across the Spider-Verse", genre: "Animation", duration: 140, imdb_rating: 8.7, release_date: "2023-04-10", description: "Miles Morales catapults across the Multiverse." },
            { id: 5, title: "John Wick: Chapter 4", genre: "Action", duration: 169, imdb_rating: 7.8, release_date: "2023-05-20", description: "John Wick uncovers a path to defeating The High Table." },
            { id: 6, title: "Guardians of the Galaxy Vol. 3", genre: "Sci-Fi", duration: 150, imdb_rating: 7.9, release_date: "2023-06-05", description: "Still reeling from the loss of Gamora, Peter Quill rallies his team." }
        ];

        const mockCinemas = [
            { id: 1, name: "CinemaMax Gaziantep", address: "İstasyon Cad. No:123", city: { name: "Gaziantep" } },
            { id: 2, name: "CinemaMax Forum", address: "Forum AVM Kat:3", city: { name: "Gaziantep" } },
            { id: 3, name: "CinemaMax Sanko Park", address: "Sanko Park AVM", city: { name: "Gaziantep" } }
        ];

        const mockShowtimes = [
            { id: 1, movie: mockMovies[0], hall: { id: 1, name: "Salon 1", cinema: mockCinemas[0] }, start_time: "2025-07-04T14:00:00" },
            { id: 2, movie: mockMovies[0], hall: { id: 2, name: "Salon 2", cinema: mockCinemas[0] }, start_time: "2025-07-04T17:00:00" },
            { id: 3, movie: mockMovies[1], hall: { id: 1, name: "Salon 1", cinema: mockCinemas[1] }, start_time: "2025-07-04T15:30:00" },
            { id: 4, movie: mockMovies[1], hall: { id: 3, name: "Salon 3", cinema: mockCinemas[1] }, start_time: "2025-07-04T19:00:00" },
            { id: 5, movie: mockMovies[2], hall: { id: 2, name: "Salon 2", cinema: mockCinemas[2] }, start_time: "2025-07-04T16:45:00" }
        ];

        // Initialize page
        document.addEventListener('DOMContentLoaded', function() {
            loadDashboardData();
            showDashboard();
        });

        // Navigation functions
        function showDashboard() {
            hideAllSections();
            document.getElementById('dashboard-section').classList.remove('hidden');
            loadDashboardData();
        }

        function showMovies() {
            hideAllSections();
            document.getElementById('movies-section').classList.remove('hidden');
            loadMoviesDisplay();
        }

        function showTicketSale() {
            hideAllSections();
            document.getElementById('ticket-sale-section').classList.remove('hidden');
            resetTicketSale();
            loadMoviesForTicket();
        }

        function showAdmin() {
            hideAllSections();
            document.getElementById('admin-section').classList.remove('hidden');
            showAdminTab('movies');
            loadMoviesAdmin();
        }

        function hideAllSections() {
            const sections = ['dashboard-section', 'movies-section', 'ticket-sale-section', 'admin-section'];
            sections.forEach(section => {
                document.getElementById(section).classList.add('hidden');
            });
        }

        // Dashboard functions
        function loadDashboardData() {
            // Simulate loading stats
            document.getElementById('totalMovies').textContent = mockMovies.length;
            document.getElementById('totalCinemas').textContent = mockCinemas.length;
            document.getElementById('totalShowtimes').textContent = mockShowtimes.length;
            document.getElementById('totalTickets').textContent = '247';
        }

        // Movies functions
        function loadMoviesDisplay() {
            const movieGrid = document.getElementById('movieGrid');
            let html = '';
            
            mockMovies.forEach(movie => {
                html += `
                    <div class="glass-effect rounded-2xl overflow-hidden card-hover">
                        <div class="h-64 bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center">
                            <i class="fas fa-film text-white text-6xl opacity-50"></i>
                        </div>
                        <div class="p-6">
                            <h3 class="text-xl font-bold text-white mb-2">${movie.title}</h3>
                            <p class="text-purple-300 text-sm mb-2">${movie.genre} • ${movie.duration} dk</p>
                            <p class="text-yellow-400 mb-4">
                                <i class="fas fa-star mr-1"></i>${movie.imdb_rating}
                            </p>
                            <button onclick="showMovieDetails(${movie.id})" class="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white py-2 rounded-xl font-semibold transition-all">
                                <i class="fas fa-info-circle mr-2"></i>Detaylar
                            </button>
                        </div>
                    </div>
                `;
            });
            
            movieGrid.innerHTML = html;
        }

        function searchMovies() {
            const searchTerm = document.getElementById('movieSearch').value.toLowerCase();
            const filteredMovies = mockMovies.filter(movie => 
                movie.title.toLowerCase().includes(searchTerm) || 
                movie.genre.toLowerCase().includes(searchTerm)
            );
            
            const movieGrid = document.getElementById('movieGrid');
            let html = '';
            
            filteredMovies.forEach(movie => {
                html += `
                    <div class="glass-effect rounded-2xl overflow-hidden card-hover">
                        <div class="h-64 bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center">
                            <i class="fas fa-film text-white text-6xl opacity-50"></i>
                        </div>
                        <div class="p-6">
                            <h3 class="text-xl font-bold text-white mb-2">${movie.title}</h3>
                            <p class="text-purple-300 text-sm mb-2">${movie.genre} • ${movie.duration} dk</p>
                            <p class="text-yellow-400 mb-4">
                                <i class="fas fa-star mr-1"></i>${movie.imdb_rating}
                            </p>
                            <button onclick="showMovieDetails(${movie.id})" class="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white py-2 rounded-xl font-semibold transition-all">
                                <i class="fas fa-info-circle mr-2"></i>Detaylar
                            </button>
                        </div>
                    </div>
                `;
            });
            
            movieGrid.innerHTML = html || '<p class="text-white text-center col-span-full">Film bulunamadı.</p>';
        }

        function showMovieDetails(movieId) {
            const movie = mockMovies.find(m => m.id === movieId);
            if (movie) {
                alert(`🎬 ${movie.title}\n\n📝 ${movie.description}\n\n⏱️ Süre: ${movie.duration} dakika\n🎭 Tür: ${movie.genre}\n⭐ IMDB: ${movie.imdb_rating}\n📅 Çıkış: ${movie.release_date}`);
            }
        }

        // Ticket Sale functions
        function resetTicketSale() {
            currentTicketStep = 1;
            selectedMovie = null;
            selectedShowtime = null;
            selectedSeats = [];
            updateTicketSteps();
        }

        function loadMoviesForTicket() {
            const movieGrid = document.getElementById('ticketMovieGrid');
            let html = '';
            
            mockMovies.slice(0, 6).forEach(movie => {
                html += `
                    <div class="glass-effect rounded-2xl p-6 card-hover cursor-pointer" onclick="selectMovieForTicket(${movie.id})">
                        <div class="h-32 bg-gradient-to-br from-purple-600 to-blue-600 rounded-xl flex items-center justify-center mb-4">
                            <i class="fas fa-film text-white text-3xl opacity-50"></i>
                        </div>
                        <h4 class="text-lg font-bold text-white mb-2">${movie.title}</h4>
                        <p class="text-purple-300 text-sm">${movie.genre} • ${movie.duration} dk</p>
                        <p class="text-yellow-400 mt-2">
                            <i class="fas fa-star mr-1"></i>${movie.imdb_rating}
                        </p>
                    </div>
                `;
            });
            
            movieGrid.innerHTML = html;
        }

        function selectMovieForTicket(movieId) {
            selectedMovie = mockMovies.find(m => m.id === movieId);
            currentTicketStep = 2;
            updateTicketSteps();
            loadShowtimesForTicket();
        }

        function loadShowtimesForTicket() {
            const showtimes = mockShowtimes.filter(s => s.movie.id === selectedMovie.id);
            const showtimeGrid = document.getElementById('showtimeGrid');
            let html = '';
            
            showtimes.forEach(showtime => {
                const startTime = new Date(showtime.start_time);
                html += `
                    <div class="glass-effect rounded-xl p-4 card-hover cursor-pointer" onclick="selectShowtimeForTicket(${showtime.id})">
                        <h4 class="text-lg font-semibold text-white mb-2">${showtime.hall.cinema.name}</h4>
                        <p class="text-purple-300 text-sm mb-2">${showtime.hall.name}</p>
                        <p class="text-emerald-400 font-bold">${startTime.toLocaleString('tr-TR')}</p>
                    </div>
                `;
            });
            
            showtimeGrid.innerHTML = html;
        }

        function selectShowtimeForTicket(showtimeId) {
            selectedShowtime = mockShowtimes.find(s => s.id === showtimeId);
            currentTicketStep = 3;
            updateTicketSteps();
            loadSeatMap();
        }

        function loadSeatMap() {
            const seatMap = document.getElementById('seatMap');
            let html = '';
            
            // Generate seat map (8 rows, 12 seats per row)
            const rows = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
            const seatsPerRow = 12;
            
            rows.forEach(row => {
                html += `<div class="flex justify-center items-center space-x-2 mb-2">`;
                html += `<div class="w-8 text-center font-bold text-white">${row}</div>`;
                
                for (let seat = 1; seat <= seatsPerRow; seat++) {
                    const seatId = `${row}${seat}`;
                    const isOccupied = Math.random() < 0.3; // Random occupied seats
                    const isSelected = selectedSeats.includes(seatId);
                    
                    let bgColor = 'bg-emerald-500 hover:bg-emerald-400';
                    if (isOccupied) bgColor = 'bg-red-500 cursor-not-allowed';
                    if (isSelected) bgColor = 'bg-blue-500';
                    
                    html += `
                        <button class="seat w-8 h-8 ${bgColor} text-white text-xs rounded-lg font-bold ${!isOccupied ? 'cursor-pointer' : ''}"
                                ${!isOccupied ? `onclick="toggleSeat('${seatId}')"` : 'disabled'}>
                            ${seat}
                        </button>
                    `;
                }
                
                html += `</div>`;
            });
            
            seatMap.innerHTML = html;
        }

        function toggleSeat(seatId) {
            if (selectedSeats.includes(seatId)) {
                selectedSeats = selectedSeats.filter(id => id !== seatId);
            } else {
                if (selectedSeats.length < 8) {
                    selectedSeats.push(seatId);
                } else {
                    alert('Maksimum 8 koltuk seçebilirsiniz!');
                    return;
                }
            }
            
            loadSeatMap();
            updateSelectedSeatsInfo();
            
            if (selectedSeats.length > 0) {
                currentTicketStep = 4;
                updateTicketSteps();
                updateOrderSummary();
            }
        }

        function updateSelectedSeatsInfo() {
            const info = document.getElementById('selectedSeatsInfo');
            if (selectedSeats.length === 0) {
                info.textContent = 'Seçili koltuk yok';
            } else {
                info.textContent = `${selectedSeats.length} koltuk seçili: ${selectedSeats.join(', ')}`;
            }
        }

        function updateOrderSummary() {
            const summary = document.getElementById('orderSummary');
            const total = selectedSeats.length * seatPrice;
            
            summary.innerHTML = `
                <div class="space-y-2">
                    <div class="flex justify-between">
                        <span>Film:</span>
                        <span class="font-medium">${selectedMovie.title}</span>
                    </div>
                    <div class="flex justify-between">
                        <span>Seans:</span>
                        <span class="font-medium">${new Date(selectedShowtime.start_time).toLocaleString('tr-TR')}</span>
                    </div>
                    <div class="flex justify-between">
                        <span>Salon:</span>
                        <span class="font-medium">${selectedShowtime.hall.cinema.name} - ${selectedShowtime.hall.name}</span>
                    </div>
                    <div class="flex justify-between">
                        <span>Koltuklar:</span>
                        <span class="font-medium">${selectedSeats.join(', ')}</span>
                    </div>
                    <div class="flex justify-between">
                        <span>Bilet Fiyatı:</span>
                        <span class="font-medium">₺${seatPrice}</span>
                    </div>
                    <div class="flex justify-between">
                        <span>Adet:</span>
                        <span class="font-medium">${selectedSeats.length}</span>
                    </div>
                </div>
            `;
            
            document.getElementById('totalPrice').textContent = `₺${total}`;
        }

        function updateTicketSteps() {
            // Hide all steps
            for (let i = 1; i <= 4; i++) {
                document.getElementById(`ticketStep${i}`).classList.add('hidden');
            }
            
            // Show current step
            document.getElementById(`ticketStep${currentTicketStep}`).classList.remove('hidden');
            
            // Update step indicators
            const stepItems = document.querySelectorAll('.step-item');
            stepItems.forEach((item, index) => {
                const stepNumber = index + 1;
                const circle = item.querySelector('div');
                const text = item.querySelector('span');
                
                if (stepNumber <= currentTicketStep) {
                    circle.classList.remove('bg-gray-600');
                    circle.classList.add('bg-emerald-500');
                    text.classList.remove('text-gray-400');
                    text.classList.add('text-white');
                } else {
                    circle.classList.remove('bg-emerald-500');
                    circle.classList.add('bg-gray-600');
                    text.classList.remove('text-white');
                    text.classList.add('text-gray-400');
                }
            });
        }

        function completeSale() {
            const customerName = document.getElementById('customerName').value;
            const customerEmail = document.getElementById('customerEmail').value;
            const customerPhone = document.getElementById('customerPhone').value;
            const paymentMethod = document.getElementById('paymentMethod').value;
            
            if (!customerName || !customerEmail || !customerPhone) {
                alert('Lütfen tüm müşteri bilgilerini doldurun!');
                return;
            }
            
            if (selectedSeats.length === 0) {
                alert('Lütfen en az bir koltuk seçin!');
                return;
            }
            
            showLoading();
            
            // Simulate API call
            setTimeout(() => {
                hideLoading();
                const total = selectedSeats.length * seatPrice;
                showSuccessModal(`Bilet satışı başarılı!\nToplam: ₺${total}\nKoltuklar: ${selectedSeats.join(', ')}`);
                resetTicketSale();
            }, 2000);
        }

        // Admin functions
        function showAdminTab(tabName) {
            // Hide all admin tabs
            document.querySelectorAll('.admin-tab-content').forEach(tab => {
                tab.classList.add('hidden');
            });
            
            // Remove active class from all tab buttons
            document.querySelectorAll('.admin-tab-btn').forEach(btn => {
                btn.classList.remove('active', 'bg-gradient-to-r', 'from-purple-500', 'to-pink-500', 'text-white');
                btn.classList.add('bg-white/10', 'text-gray-300', 'hover:bg-white/20');
            });
            
            // Show selected tab
            document.getElementById(`admin${tabName.charAt(0).toUpperCase() + tabName.slice(1)}Tab`).classList.remove('hidden');
            
            // Add active class to clicked button
            event.target.classList.remove('bg-white/10', 'text-gray-300', 'hover:bg-white/20');
            event.target.classList.add('active', 'bg-gradient-to-r', 'from-purple-500', 'to-pink-500', 'text-white');
            
            // Load tab-specific data
            if (tabName === 'showtimes') {
                loadShowtimesAdmin();
            } else if (tabName === 'reports') {
                loadReports();
            }
        }

        function loadMoviesAdmin() {
            const movieList = document.getElementById('adminMovieList');
            let html = '';
            
            mockMovies.forEach(movie => {
                html += `
                    <div class="glass-effect rounded-xl p-6 flex justify-between items-center">
                        <div class="flex-1">
                            <h4 class="text-lg font-semibold text-white mb-2">${movie.title}</h4>
                            <p class="text-purple-300 text-sm mb-1">${movie.genre} • ${movie.duration} dk</p>
                            <p class="text-yellow-400 text-sm">
                                <i class="fas fa-star mr-1"></i>${movie.imdb_rating} • ${movie.release_date}
                            </p>
                        </div>
                        <div class="flex space-x-3">
                            <button onclick="editMovie(${movie.id})" class="bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-2 rounded-lg font-medium transition-all">
                                <i class="fas fa-edit mr-1"></i>Düzenle
                            </button>
                            <button onclick="deleteMovie(${movie.id})" class="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg font-medium transition-all">
                                <i class="fas fa-trash mr-1"></i>Sil
                            </button>
                        </div>
                    </div>
                `;
            });
            
            movieList.innerHTML = html;
        }

        function loadShowtimesAdmin() {
            const showtimeList = document.getElementById('adminShowtimeList');
            let html = '';
            
            mockShowtimes.forEach(showtime => {
                const startTime = new Date(showtime.start_time);
                html += `
                    <div class="glass-effect rounded-xl p-6 flex justify-between items-center">
                        <div class="flex-1">
                            <h4 class="text-lg font-semibold text-white mb-2">${showtime.movie.title}</h4>
                            <p class="text-purple-300 text-sm mb-1">${showtime.hall.cinema.name} - ${showtime.hall.name}</p>
                            <p class="text-emerald-400 text-sm font-medium">${startTime.toLocaleString('tr-TR')}</p>
                        </div>
                        <div class="flex space-x-3">
                            <button onclick="deleteShowtime(${showtime.id})" class="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg font-medium transition-all">
                                <i class="fas fa-trash mr-1"></i>Sil
                            </button>
                        </div>
                    </div>
                `;
            });
            
            showtimeList.innerHTML = html;
        }

        function loadReports() {
            // Simulate loading reports
            document.getElementById('dailySales').textContent = '₺12,450';
            document.getElementById('monthlySales').textContent = '₺245,780';
            document.getElementById('totalRevenue').textContent = '₺1,245,670';
            
            const popularMovies = document.getElementById('popularMovies');
            let html = '';
            
            mockMovies.slice(0, 5).forEach((movie, index) => {
                const sales = Math.floor(Math.random() * 100) + 50;
                const revenue = sales * seatPrice;
                html += `
                    <div class="flex justify-between items-center py-3 border-b border-white/20 last:border-b-0">
                        <div class="flex items-center">
                            <div class="w-8 h-8 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-lg flex items-center justify-center mr-3">
                                <span class="text-white font-bold text-sm">${index + 1}</span>
                            </div>
                            <div>
                                <div class="text-white font-medium">${movie.title}</div>
                                <div class="text-purple-300 text-sm">${movie.genre}</div>
                            </div>
                        </div>
                        <div class="text-right">
                            <div class="text-white font-semibold">${sales} bilet</div>
                            <div class="text-emerald-400 text-sm">₺${revenue}</div>
                        </div>
                    </div>
                `;
            });
            
            popularMovies.innerHTML = html;
        }

        // Form functions
        function showAddMovieForm() {
            document.getElementById('addMovieForm').classList.remove('hidden');
        }

        function hideAddMovieForm() {
            document.getElementById('addMovieForm').classList.add('hidden');
        }

        function showAddShowtimeForm() {
            document.getElementById('addShowtimeForm').classList.remove('hidden');
            loadMoviesForDropdown();
            loadHallsForDropdown();
        }

        function hideAddShowtimeForm() {
            document.getElementById('addShowtimeForm').classList.add('hidden');
        }

        function loadMoviesForDropdown() {
            const select = document.getElementById('newShowtimeMovie');
            let html = '<option value="">Film Seçin</option>';
            
            mockMovies.forEach<?php /**PATH /Users/altun/Desktop/api_server/resources/views/modern.blade.php ENDPATH**/ ?>